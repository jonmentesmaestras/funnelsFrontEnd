export default function Left() {
    return (
        <div className={"left-layout"}>
        </div>
    );
}