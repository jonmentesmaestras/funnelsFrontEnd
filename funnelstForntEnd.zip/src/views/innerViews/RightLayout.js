export default function RightLayout() {
    return (
        <div className={"right-layout"}>
        </div>
    );
}